namespace Exemplo3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            label2.Text = "Executando...";
            for (int i=1; i<=5; i++)
            {
                label1.Text = i.ToString();
                label1.Update();
                Thread.Sleep(1000);
            }
            label2.Text = "Fim!";        
        }
    }
}
