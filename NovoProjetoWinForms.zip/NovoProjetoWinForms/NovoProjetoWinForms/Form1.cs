namespace NovoProjetoWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void txtBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btn1_Click_1(object sender, EventArgs e)
        {
            String s = "Este � o texto \r\n";
            s += " no TextBox com multiline";
            txtBox1 .Text = s;
        }
    }
}
