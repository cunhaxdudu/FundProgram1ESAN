﻿namespace AtvdAva3_FundProgm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btn1_Click = new Button();
            btn2_Click = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightYellow;
            label1.Font = new Font("Segoe UI", 20.25F);
            label1.Location = new Point(12, 27);
            label1.Name = "label1";
            label1.Size = new Size(260, 37);
            label1.TabIndex = 0;
            label1.Text = "Contador de Cliques";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.LightYellow;
            label2.Font = new Font("Segoe UI", 20.25F);
            label2.Location = new Point(12, 86);
            label2.Name = "label2";
            label2.Size = new Size(206, 37);
            label2.TabIndex = 1;
            label2.Text = "Distância até 10";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.LightYellow;
            label3.Font = new Font("Segoe UI", 20.25F);
            label3.Location = new Point(12, 353);
            label3.Name = "label3";
            label3.Size = new Size(240, 37);
            label3.TabIndex = 2;
            label3.Text = "Eduardo Da Cunha";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.LightYellow;
            label4.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(12, 404);
            label4.Name = "label4";
            label4.Size = new Size(167, 37);
            label4.TabIndex = 3;
            label4.Text = "2025104798";
            label4.Click += label4_Click;
            // 
            // btn1_Click
            // 
            btn1_Click.BackColor = Color.LightYellow;
            btn1_Click.Location = new Point(680, 285);
            btn1_Click.Name = "btn1_Click";
            btn1_Click.Size = new Size(108, 61);
            btn1_Click.TabIndex = 4;
            btn1_Click.Text = "Clique Aqui Para Contar!";
            btn1_Click.UseVisualStyleBackColor = false;
            btn1_Click.Click += btn1_Click_Click;
            // 
            // btn2_Click
            // 
            btn2_Click.BackColor = Color.LightYellow;
            btn2_Click.Location = new Point(680, 377);
            btn2_Click.Name = "btn2_Click";
            btn2_Click.Size = new Size(108, 61);
            btn2_Click.TabIndex = 5;
            btn2_Click.Text = "Clique Aqui Para Zerar Contagem!";
            btn2_Click.UseVisualStyleBackColor = false;
            btn2_Click.Click += btn2_Click_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(btn2_Click);
            Controls.Add(btn1_Click);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btn1_Click;
        private Button btn2_Click;
    }
}
