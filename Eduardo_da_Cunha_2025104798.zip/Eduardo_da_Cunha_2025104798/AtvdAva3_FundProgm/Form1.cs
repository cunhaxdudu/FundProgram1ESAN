namespace AtvdAva3_FundProgm
{
    public partial class Form1 : Form
    {
        private int _contador = 0;

        private int Contador
        {
            get { return _contador; }
            set { _contador = value; }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
           
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn1_Click_Click(object sender, EventArgs e)
        {
            Contador++;
            switch (Contador)
            {
                case 1:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 9 cliques";
                    break;
                case 2:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 8 cliques";
                    break;
                case 3:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 7 cliques";
                    break;
                case 4:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 6 cliques";
                    break;
                case 5:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 5 cliques";
                    break;
                case 6:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam 4 cliques";
                    break;
                case 7:

                    label1.Text = Contador.ToString();
                    label2.Text = "Faltam mais 3 cliques";
                    break;
                case 8:

                    label1.Text = Contador.ToString();
                    label2.Text = "Agora faltam 2 cliques";
                    break;
                case 9:

                    label1.Text = Contador.ToString();
                    label2.Text = "Mais 1 apenas";
                    break;
                case 10:

                    label1.Text = Contador.ToString();
                    label2.Text = "Acabou!";
                    break;

                default:
                    label2.Text = "N�o � possivel aumentar, m�ximo de 10 cliques!";
                    break;
            }
        }

        private void btn2_Click_Click(object sender, EventArgs e)
        {
            Contador = 0;
            label1.Text = "Contador de Cliques";
            label2.Text = "Dist�ncia at� 10";
        }
    }
}
