﻿Console.WriteLine("Contador de 0 até 1000:");
Console.WriteLine("");
string a = "";
for (int i = 0; i<=1000; i++)
{
    a =  i.ToString();
    Console.WriteLine(a);
}

Console.WriteLine("");

Console.Write("Digite um valor inteiro: ");
string b = Console.ReadLine();
Console.WriteLine("");
int c = Convert.ToInt32(b);
for (int i = 0; i<=c; i++)
{
    Console.WriteLine(i);
}

Console.WriteLine("");

Console.Write("Fatorando um número: ");
string d = Console.ReadLine();
int e = Convert.ToInt32(d);
int fat = 1;
int f = e;
do
{
    fat *= f;
    f--;
    Console.WriteLine(fat);
} while (f > 0);


