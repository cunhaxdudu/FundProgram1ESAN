namespace Exemplo1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mam�e, voc� � o sol da minha vida!");
            MessageBox.Show("Mam�e, voc� � o sol da minha vida!");
        }
    }
}
