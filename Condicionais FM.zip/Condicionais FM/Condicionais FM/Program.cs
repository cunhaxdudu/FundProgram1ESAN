﻿Console.WriteLine("Digite a nota do 1º bimestre:");
double nota1bim = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Digite a nota do 2º bimestre:");
double nota2bim = Convert.ToDouble(Console.ReadLine());

double media = (nota1bim + nota2bim) / 2;
Console.WriteLine("Sua média é:"+ media);

if (media >=0 && media < 4){
    Console.WriteLine("Você foi reprovado!");
}
else if (media >= 4 && media < 7)
{
    Console.WriteLine("Você está em exame final!");
}
else if (media >=7)
{
    Console.WriteLine("Você foi aprovado!");
}

Console.WriteLine();
Console.WriteLine();

Console.WriteLine("Programa finalizado.");
