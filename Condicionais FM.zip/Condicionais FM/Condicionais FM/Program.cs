﻿Console.WriteLine("Digite sua idade:");
int idade = Convert.ToInt32(Console.ReadLine());
if (idade>=0 && idade <=12){
    Console.WriteLine("Você é uma criança.");
}
else if (idade >= 13 && idade <= 17)
{
    Console.WriteLine("Você é um adolescente.");
}
else if (idade >= 18 && idade <= 59)
{
    Console.WriteLine("Você é um adulto.");
}
else if (idade >= 60)
{
    Console.WriteLine("Você é um idoso.");
}

Console.WriteLine();
Console.WriteLine();

Console.WriteLine("Programa finalizado.");
